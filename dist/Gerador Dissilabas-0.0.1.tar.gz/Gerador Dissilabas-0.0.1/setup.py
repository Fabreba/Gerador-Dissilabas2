from setuptools import setup

with open("README.md", "r") as fh:
    readme = fh.read()

setup(name='Gerador Dissilabas',
    version='0.0.1',
    url='https://github.com/Fabreba/Gerador-Dissilabas',
    license='MIT License',
    author='Fabricio José Sousa Silva',
    long_description=readme,
    long_description_content_type="text/markdown",
    author_email='fabricioj49@gmail.com',
    keywords='Pacote',
    description='Pacote python para gerar Palavras Dissilabas',
    packages=['Generate','Base'],
    install_requires=['random'],)